#!/system/bin/sh
# Touch Performance Optimizer Uninstall Script
# Author: willygailo01@gmail.com

# Log uninstallation
echo "TouchOptimizer: Uninstalling module" >> /cache/magisk.log

# Restore default touch settings
if [ -f "/sys/class/touchpanel/device/touch_sensitivity" ]; then
  echo 0 > /sys/class/touchpanel/device/touch_sensitivity
fi

if [ -f "/sys/class/touchpanel/device/report_rate" ]; then
  # Reset to default 60Hz
  echo 60 > /sys/class/touchpanel/device/report_rate
fi

if [ -f "/sys/class/touchpanel/device/touch_boost" ]; then
  echo 0 > /sys/class/touchpanel/device/touch_boost
fi

if [ -f "/sys/class/touchpanel/device/debounce" ]; then
  # Reset to default 15ms
  echo 15 > /sys/class/touchpanel/device/debounce
fi

# Reset CPU governor
for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
  if [ -f "$cpu" ]; then
    echo "schedutil" > $cpu
  fi
done

# Reset scheduler settings
if [ -f "/proc/sys/kernel/sched_autogroup_enabled" ]; then
  echo 1 > /proc/sys/kernel/sched_autogroup_enabled
fi

if [ -f "/proc/sys/kernel/sched_latency_ns" ]; then
  echo 10000000 > /proc/sys/kernel/sched_latency_ns
fi

echo "TouchOptimizer: Module uninstallation complete" >> /cache/magisk.log
exit 0 