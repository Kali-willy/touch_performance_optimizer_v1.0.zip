##########################
# Magisk Module Installer
##########################

umask 022

# Global variables
MAGISKTMP=/sbin/.magisk
TMPDIR=/dev/tmp

ui_print() {
  echo "$1"
}

grep_prop() {
  local REGEX="s/^$1=//p"
  shift
  local FILES=$@
  [ -z "$FILES" ] && FILES='/system/build.prop'
  cat $FILES 2>/dev/null | dos2unix | sed -n "$REGEX" | head -n 1
}

install_module() {
  # Extract module files
  ui_print "- Extracting module files"
  unzip -o "$ZIP" 'system/*' -d $MODPATH >&2
  unzip -o "$ZIP" 'service.sh' -d $MODPATH >&2
  unzip -o "$ZIP" 'post-fs-data.sh' -d $MODPATH >&2
  unzip -o "$ZIP" 'uninstall.sh' -d $MODPATH >&2

  # Set permissions
  ui_print "- Setting permissions"
  set_perm_recursive $MODPATH 0 0 0755 0644
  set_perm $MODPATH/service.sh 0 0 0755
  set_perm $MODPATH/post-fs-data.sh 0 0 0755
  set_perm $MODPATH/uninstall.sh 0 0 0755
}

set_perm() {
  chmod $3 "$1"
  chown $2:$2 "$1"
}

set_perm_recursive() {
  find "$1" -type d 2>/dev/null | while read dir; do
    set_perm $dir $2 $3 $4
  done
  find "$1" -type f -o -type l 2>/dev/null | while read file; do
    set_perm $file $2 $3 $5
  done
} 