#!/system/bin/sh
# Touch Performance Optimizer
# Author: willygailo01@gmail.com
# Post-FS-Data script

MODDIR=${0%/*}

# Create log function
log_post_fs() {
  echo "TouchOptimizer-postfs: $1" >> /cache/magisk.log
}

log_post_fs "Starting post-fs-data script"

# Check Android version
SDK_VER=$(getprop ro.build.version.sdk)
if [ "$SDK_VER" -lt 29 ]; then
  log_post_fs "Android version below 10, not applying early optimizations"
  exit 0
fi

# Prepare directories and permissions for touch system
if [ -d "/sys/class/touchpanel" ]; then
  chmod 0755 /sys/class/touchpanel
  log_post_fs "Set permissions for touchpanel directory"
fi

# Early touch optimizations
# These run before the system is fully booted

# Set CPU governor to performance for boot process
# This will help with touch initialization
if [ -f "/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor" ]; then
  echo "performance" > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
  log_post_fs "Set CPU governor to performance temporarily"
fi

# Increase touch priority in kernel
if [ -f "/proc/sys/kernel/sched_latency_ns" ]; then
  echo 1000000 > /proc/sys/kernel/sched_latency_ns
  log_post_fs "Adjusted scheduler latency for touch responsiveness"
fi

# Try to set scheduler settings for touch tasks
if [ -f "/proc/sys/kernel/sched_autogroup_enabled" ]; then
  echo 0 > /proc/sys/kernel/sched_autogroup_enabled
  log_post_fs "Disabled autogroup scheduling for better touch response"
fi

log_post_fs "Post-FS-Data script completed"
exit 0 