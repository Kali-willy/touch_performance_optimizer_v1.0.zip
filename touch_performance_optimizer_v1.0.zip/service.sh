#!/system/bin/sh
# Touch Performance Optimizer
# Author: willygailo01@gmail.com
# Module for Android 10+ devices

MODDIR=${0%/*}

# Log function
log_msg() {
  echo "TouchOptimizer: $1" >> /cache/magisk.log
}

log_msg "Service script started"

# Wait for system boot completion
while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 1
done

log_msg "System boot completed, optimizing touch performance"

# Get device info
DEVICE=$(getprop ro.product.device)
ANDROID_VER=$(getprop ro.build.version.release)
SDK_VER=$(getprop ro.build.version.sdk)

log_msg "Device: $DEVICE, Android: $ANDROID_VER, SDK: $SDK_VER"

# Only run on Android 10+
if [ "$SDK_VER" -lt 29 ]; then
  log_msg "Android version below 10, exiting"
  exit 0
fi

# Touch performance optimizations
# Set lower touch latency
if [ -f "/sys/class/touchpanel/device/touch_sensitivity" ]; then
  echo 1 > /sys/class/touchpanel/device/touch_sensitivity
  log_msg "Set touch sensitivity to high"
fi

# Set higher touch report rate (if available)
if [ -f "/sys/class/touchpanel/device/report_rate" ]; then
  echo 120 > /sys/class/touchpanel/device/report_rate
  log_msg "Set touch report rate to 120Hz"
fi

# Set touch boost mode (if available)
if [ -f "/sys/class/touchpanel/device/touch_boost" ]; then
  echo 1 > /sys/class/touchpanel/device/touch_boost
  log_msg "Enabled touch boost mode"
fi

# Reduce touch debounce time
if [ -f "/sys/class/touchpanel/device/debounce" ]; then
  echo 5 > /sys/class/touchpanel/device/debounce
  log_msg "Set touch debounce to 5ms"
fi

# Apply CPU boost for touch inputs via CPU set
if [ -d "/dev/cpuset" ]; then
  echo "top-app" > /dev/cpuset/foreground/boost/tasks
  log_msg "Applied CPU boost for touch inputs"
fi

# Set touch irq scheduling to FIFO
touch_irq=$(cat /proc/interrupts | grep -i touch | awk '{print $1}' | sed 's/://')
if [ ! -z "$touch_irq" ]; then
  echo 1 > /proc/irq/$touch_irq/smp_affinity_list
  echo "FIFO" > /proc/irq/$touch_irq/sched_policy
  log_msg "Set touch IRQ scheduling to FIFO"
fi

log_msg "Touch optimizations complete"
exit 0 